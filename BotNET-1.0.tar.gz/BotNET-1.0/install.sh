# BotNET installation script.
# If this script causes problems, try "make all" instead.
# Usage: . install.sh


#!/bin/bash
echo "Compiling source code . . ."
`which gcc` src/main.c src/launch.c src/memo.c src/seen.c src/parse.c src/help.c src/log.c src/info.c -o bin/bot -pthread || (echo "Errors encountered!";return 1)
`which gcc` src/botserv.c -o bin/botserv || (echo "Errors encountered!";return 1)
echo -n "Done - "
echo "Installation Complete."
echo "Binaries will be found in bin/"
